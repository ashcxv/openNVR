﻿'use strict';

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const config = require('./config/default');
const { initDB, queryAll, logger, saveDB } = require('./lib/db');
const streamManager = require('./lib/streamManager');
const pushManager = require('./lib/pushManager');
const flvStreamManager = require('./lib/flvStreamManager');
const apiRoutes = require('./routes/api');
const liveRoutes = require('./routes/live');
const shareRoutes = require('./routes/share');

const app = express();

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// HTTP 请求日志 (排除静态文件和 HLS 分片)
app.use((req, res, next) => {
  const start = Date.now();
  const url = req.originalUrl;
  // 只记录 API 请求, 跳过静态资源和 HLS 分片
  if (url.startsWith('/api/v1') && !url.includes('/server-info')) {
    res.on('finish', () => {
      const ms = Date.now() - start;
      const level = res.statusCode >= 400 ? 'error' : 'info';
      const msg = `${req.method} ${url} → ${res.statusCode} (${ms}ms)`;
      logger[level]('HTTP', msg);
    });
  }
  next();
});

// 静态文件
app.use(express.static(path.join(__dirname, 'public')));
app.use('/apidoc', express.static(path.join(__dirname, 'apidoc')));

// HLS 流文件服务
app.use('/live', express.static(config.storage.live, {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.m3u8')) {
      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    } else if (filePath.endsWith('.ts')) {
      res.setHeader('Content-Type', 'video/MP2T');
    }
  },
}));

// 快照文件服务
app.use('/snap', express.static(config.storage.snap));

// 登录页重定向
app.get('/login', (req, res) => res.redirect('/'));

// API 路由
app.use('/api/v1', apiRoutes);
app.use('/api/v1/live', liveRoutes);
app.use('/api/v1/share', shareRoutes);
// 分享查看页面
app.get('/view/:token', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'viewer.html'));
});

// 分享信息 API (无需登录)
app.get('/api/v1/share/info/:token', (req, res) => {
  try {
    const { queryOne } = require('./lib/db');
    const share = queryOne('SELECT s.*, c.name as channel_name, c.stream_url FROM shares s LEFT JOIN channels c ON s.channel_id = c.id WHERE s.token = ? AND s.enable = 1', [req.params.token]);
    if (!share) return res.json({ code: -1, msg: '链接已失效' });
    res.json({ code: 0, data: {
      title: share.title || share.channel_name || '实时预览',
      channel_id: share.channel_id,
      hls_path: '/live/ch_' + share.channel_id + '/index.m3u8',
    }});
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 首页
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 确保存储目录存在
[config.storage.live, config.storage.record, config.storage.snap].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// 启动服务
async function main() {
  // 初始化数据库
  await initDB();
  logger.info('Server', '数据库初始化完成');

  // 启动时清理7天前的旧日志
  logger.purgeOldLogs();
  // 每6小时清理一次
  setInterval(() => logger.purgeOldLogs(), 6 * 3600 * 1000);

  const PORT = process.env.PORT || config.port;
  const server = app.listen(PORT, '0.0.0.0', () => {
    logger.info('Server', `OpenNVR 启动成功, 监听端口 ${PORT}`);
    logger.info('Server', `管理界面: http://127.0.0.1:${PORT}`);

    // 初始化 WebSocket FLV 流服务
    flvStreamManager.init(server);

    // 自动启动已启用的通道
    setTimeout(() => {
      const channels = queryAll('SELECT * FROM channels WHERE enable = 1 ORDER BY id');
      logger.info('Server', `发现 ${channels.length} 个已启用的通道`);
      channels.forEach((ch, i) => {
        setTimeout(() => streamManager.start(ch), i * config.channel.delayMs);
      });
    }, 1000);
  });
}

// 优雅退出
process.on('SIGINT', () => {
  logger.info('Server', '正在关闭...');
  streamManager.stopAll();
  flvStreamManager.stopAll();
  pushManager.stopAll();
  saveDB();
  process.exit(0);
});

process.on('SIGTERM', () => {
  logger.info('Server', '正在关闭...');
  streamManager.stopAll();
  flvStreamManager.stopAll();
  pushManager.stopAll();
  saveDB();
  process.exit(0);
});

main().catch((err) => {
  console.error('启动失败:', err);
  process.exit(1);
});



