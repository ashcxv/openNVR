﻿'use strict';

const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { queryAll, queryOne, run, changes, logger } = require('../lib/db');
const streamManager = require('../lib/streamManager');

const router = express.Router();

// ============ 通道管理 ============

router.get('/channels', (req, res) => {
  try {
    const channels = queryAll('SELECT * FROM channels ORDER BY id');
    const result = channels.map((ch) => {
      const status = streamManager.getStatus(ch.id);
      return { ...ch, stream_status: status.status, hls_path: status.hlsPath, stream_error: status.error };
    });
    res.json({ code: 0, data: result });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.get('/channels/:id', (req, res) => {
  try {
    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [parseInt(req.params.id)]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });
    const status = streamManager.getStatus(ch.id);
    res.json({ code: 0, data: { ...ch, stream_status: status.status, hls_path: status.hlsPath } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.post('/channels', (req, res) => {
  try {
    const { name, stream_url, description, enable, record_enable, video_width, video_height, video_framerate, video_bitrate } = req.body;
    if (!stream_url) return res.json({ code: -1, msg: '流地址不能为空' });

    const id = run(
      `INSERT INTO channels (name, stream_url, description, enable, record_enable, video_width, video_height, video_framerate, video_bitrate)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name || '', stream_url, description || '',
        enable !== undefined ? enable : 1,
        record_enable || 0,
        video_width || 960, video_height || 540,
        video_framerate || 25, video_bitrate || 1024,
      ]
    );

    logger.info('Channel', `添加通道 [${name}], ID: ${id}`);

    if (enable !== 0) {
      const ch = queryOne('SELECT * FROM channels WHERE id = ?', [id]);
      if (ch) streamManager.start(ch);
    }

    res.json({ code: 0, data: { id } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.put('/channels/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [id]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });

    const { name, stream_url, description, enable, record_enable, video_width, video_height, video_framerate, video_bitrate } = req.body;

    run(
      `UPDATE channels SET name=?, stream_url=?, description=?, enable=?, record_enable=?,
       video_width=?, video_height=?, video_framerate=?, video_bitrate=?, updated_at=datetime('now','localtime')
       WHERE id=?`,
      [
        name !== undefined ? name : ch.name,
        stream_url || ch.stream_url,
        description !== undefined ? description : ch.description,
        enable !== undefined ? enable : ch.enable,
        record_enable !== undefined ? record_enable : ch.record_enable,
        video_width || ch.video_width,
        video_height || ch.video_height,
        video_framerate || ch.video_framerate,
        video_bitrate || ch.video_bitrate,
        id,
      ]
    );

    streamManager.stop(id);
    const updated = queryOne('SELECT * FROM channels WHERE id = ?', [id]);
    if (updated && updated.enable) {
      setTimeout(() => streamManager.start(updated), 500);
    }

    logger.info('Channel', `更新通道 ID: ${id}`);
    res.json({ code: 0, msg: '更新成功' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.delete('/channels/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [id]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });

    streamManager.stop(id);
    run('DELETE FROM channels WHERE id = ?', [id]);

    logger.info('Channel', `删除通道 [${ch.name}], ID: ${id}`);
    res.json({ code: 0, msg: '删除成功' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// ============ 流控制 ============

router.post('/streams/:id/start', (req, res) => {
  try {
    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [parseInt(req.params.id)]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });
    const result = streamManager.start(ch);
    res.json({ code: result.ok ? 0 : -1, data: result });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.post('/streams/:id/stop', (req, res) => {
  try {
    streamManager.stop(parseInt(req.params.id));
    res.json({ code: 0, msg: '已停止' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.get('/streams/:id/status', (req, res) => {
  try {
    const status = streamManager.getStatus(parseInt(req.params.id));
    res.json({ code: 0, data: status });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.get('/streams/status', (req, res) => {
  try {
    const status = streamManager.getAllStatus();
    res.json({ code: 0, data: status });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

router.post('/streams/start-all', (req, res) => {
  try {
    const channels = queryAll('SELECT * FROM channels WHERE enable = 1 ORDER BY id');
    let started = 0;
    for (const ch of channels) {
      const result = streamManager.start(ch);
      if (result.ok) started++;
    }
    res.json({ code: 0, data: { started, total: channels.length } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// ============ 快照 ============

router.post('/snapshot/:id', async (req, res) => {
  try {
    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [parseInt(req.params.id)]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });
    const snapPath = await streamManager.takeSnapshot(ch.id, ch.stream_url);
    res.json({ code: 0, data: { path: snapPath } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// ============ 系统信息 ============

router.get('/server-info', (req, res) => {
  try {
    const chCount = queryOne('SELECT COUNT(*) as count FROM channels');
    const channelCount = chCount ? chCount.count : 0;
    const statusMap = streamManager.getAllStatus();
    const runningCount = Object.values(statusMap).filter((s) => s.status === 'running').length;
    const errorCount = Object.values(statusMap).filter((s) => s.status === 'error').length;

    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const mins = Math.floor((uptime % 3600) / 60);

    let uptimeStr;
    if (days > 0) uptimeStr = `${days}天${hours}时`;
    else if (hours > 0) uptimeStr = `${hours}时${mins}分`;
    else uptimeStr = `${mins}分`;

    // 系统资源
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memPercent = Math.round((usedMem / totalMem) * 100);

    // CPU 使用率
    const cpus = os.cpus();
    let totalIdle = 0, totalTick = 0;
    cpus.forEach(cpu => {
      for (const type in cpu.times) totalTick += cpu.times[type];
      totalIdle += cpu.times.idle;
    });
    const cpuPercent = Math.round(((totalTick - totalIdle) / totalTick) * 100);

    // 磁盘空间
    let diskInfo = { total: 0, free: 0, used: 0, percent: 0 };
    try {
      const drive = process.cwd().split(path.sep)[0] + path.sep;
      const stats = require('child_process').execSync(
        `wmic logicaldisk where "DeviceID='${drive.replace('\\', '')}'" get FreeSpace,Size /format:csv`,
        { encoding: 'utf8', timeout: 3000 }
      );
      const lines = stats.trim().split('\n').filter(l => l.includes(','));
      if (lines.length > 0) {
        const parts = lines[lines.length - 1].split(',');
        if (parts.length >= 3) {
          diskInfo.free = parseInt(parts[1]) || 0;
          diskInfo.total = parseInt(parts[2]) || 0;
          diskInfo.used = diskInfo.total - diskInfo.free;
          diskInfo.percent = diskInfo.total > 0 ? Math.round((diskInfo.used / diskInfo.total) * 100) : 0;
        }
      }
    } catch (e) {}

    // 存储目录大小
    let storageSize = 0;
    try {
      const config = require('../config/default');
      const calcDir = (dir) => {
        if (!fs.existsSync(dir)) return 0;
        let size = 0;
        for (const f of fs.readdirSync(dir)) {
          const fp = path.join(dir, f);
          const stat = fs.statSync(fp);
          if (stat.isDirectory()) size += calcDir(fp);
          else size += stat.size;
        }
        return size;
      };
      storageSize = calcDir(config.storage.live);
    } catch (e) {}

    // 最近日志
    const recentLogs = queryAll('SELECT * FROM logs ORDER BY id DESC LIMIT 10');

    // FFmpeg 进程数
    let ffmpegCount = 0;
    try {
      const { execSync } = require('child_process');
      const out = execSync('tasklist /FI "IMAGENAME eq ffmpeg.exe" /NH', { encoding: 'utf8', timeout: 3000 });
      ffmpegCount = (out.match(/ffmpeg\.exe/g) || []).length;
    } catch (e) {}

    res.json({
      code: 0,
      data: {
        name: 'OpenNVR',
        version: '1.0.0',
        uptime: uptimeStr,
        uptimeSeconds: uptime,
        channelCount,
        runningCount,
        errorCount,
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch,
        cpu: { percent: cpuPercent, cores: cpus.length, model: cpus[0] ? cpus[0].model : 'Unknown' },
        memory: { total: totalMem, used: usedMem, free: freeMem, percent: memPercent },
        disk: diskInfo,
        storageSize,
        ffmpegCount,
        recentLogs,
      },
    });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// ============ 日志 ============

router.get('/logs', (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 100, 1000);
    const level = req.query.level;
    const startDate = req.query.start; // YYYY-MM-DD
    const endDate = req.query.end;     // YYYY-MM-DD
    let sql = 'SELECT * FROM logs';
    const params = [];
    const conditions = [];

    if (level) {
      conditions.push('level = ?');
      params.push(level);
    }
    if (startDate) {
      conditions.push('created_at >= ?');
      params.push(startDate + ' 00:00:00');
    }
    if (endDate) {
      conditions.push('created_at <= ?');
      params.push(endDate + ' 23:59:59');
    }

    if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
    sql += ' ORDER BY id DESC LIMIT ?';
    params.push(limit);

    const logs = queryAll(sql, params);
    res.json({ code: 0, data: logs });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// ============ 登录 ============

router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.json({ code: -1, msg: '用户名和密码不能为空' });

    const user = queryOne('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
    if (!user) return res.json({ code: -1, msg: '用户名或密码错误' });

    const token = Buffer.from(`${user.id}:${user.username}:${Date.now()}`).toString('base64');
    res.json({ code: 0, data: { token, username: user.username, role: user.role } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

module.exports = router;
