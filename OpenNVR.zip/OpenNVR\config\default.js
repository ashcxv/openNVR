﻿'use strict';

const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// 检测最佳硬件编码器
function detectEncoder() {
  const ffmpegPath = (() => {
    const local = path.join(__dirname, '..', 'ffmpeg.exe');
    if (fs.existsSync(local)) return local;
    try { return require('ffmpeg-static'); } catch(e) { return 'ffmpeg'; }
  })();

  // 按优先级尝试: NVENC > QSV > AMF > libx264 (软件)
  const candidates = [
    { name: 'h264_nvenc', label: 'NVENC (NVIDIA GPU)' },
    { name: 'h264_qsv', label: 'QSV (Intel GPU)' },
    { name: 'h264_amf', label: 'AMF (AMD GPU)' },
  ];

  for (const c of candidates) {
    try {
      execSync(`"${ffmpegPath}" -hide_banner -f lavfi -i testsrc=duration=0.1:size=64x64:rate=1 -c:v ${c.name} -f null -`, {
        stdio: 'pipe', timeout: 5000
      });
      console.log(`[编码器] 检测到 ${c.label}, 使用硬件编码`);
      return c.name;
    } catch (e) {}
  }

  console.log('[编码器] 未检测到硬件编码器, 使用 libx264 软件编码');
  return 'libx264';
}

const encoder = detectEncoder();

module.exports = {
  // Web 服务端口
  port: 10800,

  // 数据库路径
  dbPath: path.join(__dirname, '..', 'data', 'opennvr.db'),

  // 存储路径
  storage: {
    live: path.join(__dirname, '..', 'storage', 'live'),
    record: path.join(__dirname, '..', 'storage', 'record'),
    snap: path.join(__dirname, '..', 'storage', 'snap'),
  },

  // FFmpeg 配置
  ffmpeg: {
    // 优先使用项目目录下的 ffmpeg.exe, 否则回退到 ffmpeg-static
    path: (() => {
      const local = path.join(__dirname, '..', 'ffmpeg.exe');
      if (fs.existsSync(local)) return local;
      try { return require('ffmpeg-static'); } catch(e) { return 'ffmpeg'; }
    })(),
    // 硬件编码器 (自动检测)
    encoder: encoder,
    // 是否为硬件编码
    isHardwareEncoder: encoder !== 'libx264',
    // HLS 分片时长(秒)
    hlsTime: 1,
    // HLS 列表大小
    hlsListSize: 3,
    // HLS 分片文件保留数量
    hlsFlags: 'delete_segments',
    // 超时时间(微秒)
    rtspTimeout: 5000000,
  },

  // 录像配置
  record: {
    // 录像分片时长(秒)
    segmentTime: 300,
    // 磁盘清理阈值(剩余空间百分比)
    cleanPercent: 5,
    // 磁盘清理阈值(剩余空间 MB)
    cleanSizeMB: 5120,
  },

  // 快照配置
  snapshot: {
    // 快照抓取间隔(秒)
    interval: 60,
    // 快照超时(秒)
    timeout: 10,
  },

  // Token 配置
  token: {
    // Token 有效期(秒)
    timeout: 604800,
    // JWT 密钥
    secret: 'open-nvr-secret-key-' + Date.now(),
  },

  // 通道默认配置
  channel: {
    // 通道重连间隔(秒)
    reconnectInterval: 30,
    // 通道启动间隔(毫秒)
    delayMs: 500,
  },
};
