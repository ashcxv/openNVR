﻿'use strict';
console.log('app.js loaded, version: 200553');


// ============ 状态 ============
const state = {
  token: localStorage.getItem('token') || '',
  channels: [],
  hlsPlayers: {},
  currentPage: 'dashboard',
  refreshTimer: null,
};

const PLATFORMS = {
  'B站直播': 'rtmp://live-push.bilivideo.com/live-bvc/',
  '抖音直播': 'rtmp://push.douyin.com/live/',
  '斗鱼直播': 'rtmp://sendtc.douyu.com/live/',
  '虎牙直播': 'rtmp://va.openhuya.com/huya/',
  'YouTube': 'rtmp://a.rtmp.youtube.com/live2/',
  'Twitch': 'rtmp://live-jfk.twitch.tv/app/',
  '自定义RTMP': '',
};

// ============ API ============
async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api/v1' + path, opts);
  return res.json();
}

// ============ 登录 ============
async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  const res = await api('POST', '/login', { username, password });
  if (res.code === 0) {
    state.token = res.data.token;
    localStorage.setItem('token', state.token);
    document.getElementById('user-info').textContent = res.data.username;
    showMainApp();
  } else {
    alert(res.msg || '登录失败');
  }
  return false;
}

function handleLogout() {
  state.token = '';
  localStorage.removeItem('token');
  location.reload();
}

function showMainApp() {
  document.getElementById('login-page').style.display = 'none';
  document.getElementById('main-app').style.display = 'flex';
  switchPage('dashboard');
  startAutoRefresh();
}

// ============ 页面切换 ============
function switchPage(page) {
  state.currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pageEl = document.getElementById('page-' + page);
  const navEl = document.querySelector('[data-page="' + page + '"]');
  if (pageEl) pageEl.classList.add('active');
  if (navEl) navEl.classList.add('active');

  if (page === 'dashboard') loadDashboard();
  else if (page === 'live') loadLiveView();
  else if (page === 'channels') loadChannels();
  else if (page === 'logs') loadLogs();
  else if (page === 'livepush') loadLivePush();
}

// ============ 控制台 ============
async function loadDashboard() {
  const res = await api('GET', '/server-info');
  if (res.code === 0) {
    const d = res.data;
    document.getElementById('stat-channels').textContent = d.channelCount;
    document.getElementById('stat-running').textContent = d.runningCount;
    document.getElementById('stat-uptime').textContent = d.uptime;
    document.getElementById('stat-version').textContent = d.nodeVersion;
  }
}

// ============ 实时预览 ============
async function loadLiveView() {
  const res = await api('GET', '/channels');
  if (res.code === 0) { state.channels = res.data; renderGrid(); }
}

function changeGrid() { renderGrid(parseInt(document.getElementById('grid-select').value)); }

function renderGrid(gridSize) {
  if (!gridSize) gridSize = 2;
  const container = document.getElementById('live-grid');
  container.className = 'live-grid grid-' + gridSize + 'x' + gridSize;
  Object.values(state.hlsPlayers).forEach(p => { if (p.destroy) p.destroy(); });
  state.hlsPlayers = {};

  const total = gridSize * gridSize;
  let html = '';
  for (let i = 0; i < total; i++) {
    const ch = state.channels[i];
    if (ch) {
      html += '<div class="video-cell" id="cell-' + ch.id + '">' +
        '<div class="cell-header">' + (ch.name || '通道 ' + ch.id) + '</div>' +
        '<div class="cell-overlay" id="overlay-' + ch.id + '"><i class="mdi mdi-cctv"></i><span>等待连接...</span></div>' +
        '<video id="video-' + ch.id + '" muted autoplay></video>' +
        '<div class="cell-toolbar">' +
          '<button onclick="startStream(' + ch.id + ')"><i class="mdi mdi-play"></i> 播放</button>' +
          '<button onclick="stopStream(' + ch.id + ')"><i class="mdi mdi-stop"></i> 停止</button>' +
        '</div></div>';
    } else {
      html += '<div class="video-cell"><div class="cell-overlay"><i class="mdi mdi-plus-circle-outline"></i><span>空闲窗口</span></div></div>';
    }
  }
  container.innerHTML = html;
  state.channels.forEach((ch, i) => {
    if (i < total && ch.stream_status === 'running' && ch.hls_path) playStream(ch.id, ch.hls_path);
  });
}

function playStream(channelId, hlsPath) {
  const video = document.getElementById('video-' + channelId);
  const overlay = document.getElementById('overlay-' + channelId);
  if (!video) return;
  if (Hls.isSupported()) {
    if (state.hlsPlayers[channelId]) state.hlsPlayers[channelId].destroy();
    const hls = new Hls({ liveDurationInfinity: true, lowLatencyMode: true, maxBufferLength: 3 });
    hls.loadSource(hlsPath);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); if (overlay) overlay.style.display = 'none'; });
    state.hlsPlayers[channelId] = hls;
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = hlsPath;
    video.addEventListener('loadedmetadata', () => { video.play().catch(() => {}); if (overlay) overlay.style.display = 'none'; });
  }
}

async function startStream(channelId) {
  const res = await api('POST', '/streams/' + channelId + '/start');
  if (res.code === 0) {
    setTimeout(() => { if (res.data && res.data.hlsPath) playStream(channelId, res.data.hlsPath); }, 3000);
  } else { alert(res.msg || '启动失败'); }
}

async function stopStream(channelId) {
  await api('POST', '/streams/' + channelId + '/stop');
  if (state.hlsPlayers[channelId]) { state.hlsPlayers[channelId].destroy(); delete state.hlsPlayers[channelId]; }
  const v = document.getElementById('video-' + channelId);
  const o = document.getElementById('overlay-' + channelId);
  if (v) v.src = '';
  if (o) { o.style.display = 'flex'; o.querySelector('span').textContent = '已停止'; }
}

// ============ 通道管理 ============
async function loadChannels() {
  const res = await api('GET', '/channels');
  if (res.code !== 0) return;
  state.channels = res.data;
  document.getElementById('channel-list').innerHTML = res.data.map(ch =>
    '<tr><td>' + ch.id + '</td><td>' + (ch.name || '-') + '</td>' +
    '<td style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + ch.stream_url + '">' + ch.stream_url + '</td>' +
    '<td>' + statusBadge(ch.stream_status) + '</td>' +
    '<td>' + (ch.enable ? '<span class="text-success">是</span>' : '否') + '</td>' +
    '<td>' +
      '<button class="btn btn-sm btn-primary" onclick="editChannel(' + ch.id + ')"><i class="mdi mdi-pencil"></i></button> ' +
      '<button class="btn btn-sm btn-danger" onclick="deleteChannel(' + ch.id + ')"><i class="mdi mdi-delete"></i></button>' +
    '</td></tr>'
  ).join('');
}

function statusBadge(s) {
  const m = { running: 'success', connecting: 'warning', error: 'danger', stopped: 'default' };
  const t = { running: '运行中', connecting: '连接中', error: '错误', stopped: '已停止' };
  return '<span class="badge badge-' + (m[s] || 'default') + '">' + (t[s] || '未知') + '</span>';
}

function showChannelDialog(ch) {
  document.getElementById('edit-channel-id').value = ch ? ch.id : '';
  document.getElementById('edit-name').value = ch ? ch.name : '';
  document.getElementById('edit-stream-url').value = ch ? ch.stream_url : '';
  document.getElementById('edit-description').value = ch ? (ch.description || '') : '';
  document.getElementById('dialog-title').textContent = ch ? '编辑通道' : '添加通道';
  document.getElementById('channel-dialog').style.display = 'flex';
}

function closeChannelDialog() { document.getElementById('channel-dialog').style.display = 'none'; }

function editChannel(id) { const ch = state.channels.find(c => c.id === id); if (ch) showChannelDialog(ch); }

async function saveChannel(e) {
  e.preventDefault();
  const id = document.getElementById('edit-channel-id').value;
  const body = {
    name: document.getElementById('edit-name').value,
    stream_url: document.getElementById('edit-stream-url').value,
    description: document.getElementById('edit-description').value,
    enable: 1,
  };
  const res = id ? await api('PUT', '/channels/' + id, body) : await api('POST', '/channels', body);
  if (res.code === 0) { closeChannelDialog(); loadChannels(); }
  else alert(res.msg || '保存失败');
  return false;
}

async function deleteChannel(id) {
  if (!confirm('确定删除该通道?')) return;
  const res = await api('DELETE', '/channels/' + id);
  if (res.code === 0) loadChannels(); else alert(res.msg || '删除失败');
}

// ============ 直播推流 ============
async function loadLivePush() {
  const chRes = await api('GET', '/channels');
  const sel = document.getElementById('push-channel-id');
  if (sel && chRes.code === 0) {
    sel.innerHTML = chRes.data.map(c => '<option value="' + c.id + '">' + (c.name || '通道 ' + c.id) + '</option>').join('');
  }

  const res = await api('GET', '/live/pushes');
  if (res.code !== 0) return;
  const container = document.getElementById('push-list');
  if (!res.data.length) {
    container.innerHTML = '<div style="text-align:center;color:#999;padding:60px"><i class="mdi mdi-broadcast" style="font-size:48px;display:block;margin-bottom:12px"></i>暂无推流任务<br><br>点击右上角「添加推流」开始</div>';
    return;
  }
  container.innerHTML = res.data.map(p => {
    const dotClass = p.live_status || 'stopped';
    const uptime = p.live_status === 'running' ? fmtUptime(p.uptime) : (p.live_error || '已停止');
    return '<div class="push-card">' +
      '<div class="push-card-header"><h4><span class="push-live-dot ' + dotClass + '"></span>' + p.platform + '</h4>' + statusBadge(p.live_status) + '</div>' +
      '<div class="push-info"><i class="mdi mdi-cctv"></i> ' + (p.channel_name || '通道 ' + p.channel_id) + '</div>' +
      '<div class="push-info"><i class="mdi mdi-broadcast"></i> ' + p.push_url + (p.push_key ? '/' + p.push_key.substring(0, 8) + '...' : '') + '</div>' +
      '<div class="push-status-bar"><i class="mdi mdi-clock-outline"></i> ' + uptime + '</div>' +
      '<div class="push-actions">' +
        (p.live_status === 'running'
          ? '<button class="btn btn-sm btn-default" onclick="stopPush(' + p.id + ')"><i class="mdi mdi-stop"></i> 停止</button>'
          : '<button class="btn btn-sm btn-success" onclick="startPush(' + p.id + ')"><i class="mdi mdi-play"></i> 推流</button>') +
        '<button class="btn btn-sm btn-primary" onclick="editPush(' + p.id + ')"><i class="mdi mdi-pencil"></i></button>' +
        '<button class="btn btn-sm btn-danger" onclick="deletePush(' + p.id + ')"><i class="mdi mdi-delete"></i></button>' +
      '</div></div>';
  }).join('');
}

function fmtUptime(ms) {
  if (!ms) return '-';
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (h > 0) return '已推流 ' + h + '时' + (m % 60) + '分';
  if (m > 0) return '已推流 ' + m + '分' + (s % 60) + '秒';
  return '已推流 ' + s + '秒';
}

function showPushDialog(push) {
  document.getElementById('edit-push-id').value = push ? push.id : '';
  document.getElementById('push-platform').value = push ? push.platform : 'B站直播';
  document.getElementById('push-url').value = push ? push.push_url : PLATFORMS['B站直播'];
  document.getElementById('push-key').value = push ? (push.push_key || '') : '';
  const sel = document.getElementById('push-channel-id');
  if (sel && push) sel.value = push.channel_id;
  document.getElementById('push-dialog-title').textContent = push ? '编辑推流' : '添加推流';
  document.getElementById('push-dialog').style.display = 'flex';
}

function closePushDialog() { document.getElementById('push-dialog').style.display = 'none'; }

function onPlatformChange() {
  const p = document.getElementById('push-platform').value;
  document.getElementById('push-url').value = PLATFORMS[p] || '';
}

async function editPush(id) {
  const res = await api('GET', '/live/pushes');
  if (res.code === 0) { const p = res.data.find(x => x.id === id); if (p) showPushDialog(p); }
}

async function savePush(e) {
  e.preventDefault();
  const id = document.getElementById('edit-push-id').value;
  const body = {
    channel_id: parseInt(document.getElementById('push-channel-id').value),
    platform: document.getElementById('push-platform').value,
    push_url: document.getElementById('push-url').value,
    push_key: document.getElementById('push-key').value,
    enable: 1,
  };
  const res = id ? await api('PUT', '/live/pushes/' + id, body) : await api('POST', '/live/pushes', body);
  if (res.code === 0) { closePushDialog(); loadLivePush(); }
  else alert(res.msg || '保存失败');
  return false;
}

async function startPush(id) {
  const res = await api('POST', '/live/pushes/' + id + '/start');
  if (res.code === 0) setTimeout(loadLivePush, 2000);
  else alert(res.msg || '启动失败');
}

async function stopPush(id) { await api('POST', '/live/pushes/' + id + '/stop'); loadLivePush(); }

async function deletePush(id) {
  if (!confirm('确定删除该推流任务?')) return;
  const res = await api('DELETE', '/live/pushes/' + id);
  if (res.code === 0) loadLivePush(); else alert(res.msg || '删除失败');
}

// ============ 日志 ============
async function loadLogs() {
  const res = await api('GET', '/logs?limit=200');
  if (res.code !== 0) return;
  const levelBadge = l => {
    const m = { info: 'success', warn: 'warning', error: 'danger' };
    return '<span class="badge badge-' + (m[l] || 'default') + '">' + l.toUpperCase() + '</span>';
  };
  document.getElementById('log-list').innerHTML = res.data.map(log =>
    '<tr><td>' + log.created_at + '</td><td>' + levelBadge(log.level) + '</td><td>' + log.module + '</td><td>' + log.message + '</td></tr>'
  ).join('');
}

// ============ 自动刷新 ============
function startAutoRefresh() {
  stopAutoRefresh();
  state.refreshTimer = setInterval(() => {
    if (state.currentPage === 'dashboard') loadDashboard();
    else if (state.currentPage === 'channels') loadChannels();
    else if (state.currentPage === 'livepush') loadLivePush();
  }, 5000);
}

function stopAutoRefresh() { if (state.refreshTimer) { clearInterval(state.refreshTimer); state.refreshTimer = null; } }

// ============ 导航绑定 ============
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const page = item.dataset.page;
    if (page) switchPage(page);
  });
});

// ============ 初始化 ============
if (state.token) showMainApp();

