@echo off
chcp 65001 >nul
echo ========================================
echo   OpenNVR 一键部署
echo ========================================
echo.

REM 检查 Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Node.js，请先安装 Node.js
    echo 下载地址: https://nodejs.org/
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node -v') do echo [OK] Node.js 版本: %%i

REM 检查 ffmpeg.exe
if not exist "%~dp0ffmpeg.exe" (
    echo.
    echo [警告] 未找到 ffmpeg.exe，请将 ffmpeg.exe 放到本目录下
    echo 下载地址: https://www.gyan.dev/ffmpeg/builds/
    echo 选择 release full 版本，解压后将 bin\ffmpeg.exe 复制到本目录
    echo.
)

REM 安装依赖（如果 node_modules 不存在或不完整）
if not exist "%~dp0node_modules" (
    echo [提示] 正在安装依赖...
    cd /d "%~dp0"
    npm install --production --registry https://registry.npmmirror.com
    if %errorlevel% neq 0 (
        echo [错误] 依赖安装失败，请检查网络连接
        pause
        exit /b 1
    )
)

echo.
echo [OK] 部署完成！
echo.
echo 启动方式: 双击 start.bat
echo 管理界面: http://127.0.0.1:10800
echo 默认账号: admin / admin123
echo.
pause
