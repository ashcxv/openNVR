﻿'use strict';

const express = require('express');
const crypto = require('crypto');
const QRCode = require('qrcode');
const path = require('path');
const os = require('os');
const { queryAll, queryOne, run, logger } = require('../lib/db');

const router = express.Router();

// 获取本机 IP
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return '127.0.0.1';
}

// 生成分享链接
router.post('/create', (req, res) => {
  try {
    const { channel_id } = req.body;
    if (!channel_id) return res.json({ code: -1, msg: '请选择通道' });

    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [parseInt(channel_id)]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });

    // 生成唯一 token
    const token = crypto.randomBytes(8).toString('hex');
    const title = ch.name || `通道${ch.id}`;

    run('INSERT INTO shares (channel_id, token, title) VALUES (?, ?, ?)', [parseInt(channel_id), token, title]);

    const ip = getLocalIP();
    const port = require('../config/default').port;
    const url = `http://${ip}:${port}/view/${token}`;

    logger.info('Share', `生成分享链接: [${title}] -> ${token}`);

    res.json({ code: 0, data: { token, url, title, channel_id: parseInt(channel_id) } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 获取分享列表
router.get('/list', (req, res) => {
  try {
    const shares = queryAll('SELECT s.*, c.name as channel_name FROM shares s LEFT JOIN channels c ON s.channel_id = c.id ORDER BY s.id DESC');
    const ip = getLocalIP();
    const port = require('../config/default').port;
    const result = shares.map(s => ({
      ...s,
      url: `http://${ip}:${port}/view/${s.token}`,
    }));
    res.json({ code: 0, data: result });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 删除分享
router.delete('/:id', (req, res) => {
  try {
    run('DELETE FROM shares WHERE id = ?', [parseInt(req.params.id)]);
    res.json({ code: 0, msg: '已删除' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 获取二维码 (返回 PNG 图片)
router.get('/qrcode/:token', async (req, res) => {
  try {
    const share = queryOne('SELECT * FROM shares WHERE token = ? AND enable = 1', [req.params.token]);
    if (!share) return res.status(404).send('Not Found');

    const ip = getLocalIP();
    const port = require('../config/default').port;
    const url = `http://${ip}:${port}/view/${share.token}`;

    const qrBuffer = await QRCode.toBuffer(url, {
      width: 300,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
    });

    res.setHeader('Content-Type', 'image/png');
    res.send(qrBuffer);
  } catch (e) {
    res.status(500).send(e.message);
  }
});

module.exports = router;
