@echo off
chcp 65001 >nul
title OpenNVR
echo.
echo  [OpenNVR] Video Management System v1.0.0
echo  ------------------------------------------
echo.
echo  Web UI:  http://127.0.0.1:10800
echo  Account: admin / admin123
echo.
cd /d "%~dp0"
node server.js
pause