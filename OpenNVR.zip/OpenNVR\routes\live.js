﻿'use strict';

const express = require('express');
const { queryAll, queryOne, run, logger } = require('../lib/db');
const pushManager = require('../lib/pushManager');

const router = express.Router();

// 预设平台
const PLATFORMS = [
  { name: 'B站直播', url: 'rtmp://live-push.bilivideo.com/live-bvc/', placeholder: '填入推流码' },
  { name: '抖音直播', url: 'rtmp://push.douyin.com/live/', placeholder: '填入推流码' },
  { name: '斗鱼直播', url: 'rtmp://sendtc.douyu.com/live/', placeholder: '填入推流码' },
  { name: '虎牙直播', url: 'rtmp://va.openhuya.com/huya/', placeholder: '填入推流码' },
  { name: 'YouTube', url: 'rtmp://a.rtmp.youtube.com/live2/', placeholder: '填入Stream Key' },
  { name: 'Twitch', url: 'rtmp://live-jfk.twitch.tv/app/', placeholder: '填入Stream Key' },
  { name: '自定义RTMP', url: '', placeholder: '填入完整RTMP地址' },
];

// 获取预设平台列表
router.get('/platforms', (req, res) => {
  res.json({ code: 0, data: PLATFORMS });
});

// 获取所有推流任务
router.get('/pushes', (req, res) => {
  try {
    const pushes = queryAll('SELECT * FROM live_pushes ORDER BY id DESC');
    const result = pushes.map((p) => {
      const status = pushManager.getStatus(p.id);
      return { ...p, live_status: status.status, live_error: status.error, uptime: status.uptime };
    });
    res.json({ code: 0, data: result });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 添加推流任务
router.post('/pushes', (req, res) => {
  try {
    const { channel_id, platform, push_url, push_key, enable } = req.body;
    if (!channel_id) return res.json({ code: -1, msg: '请选择通道' });
    if (!push_url) return res.json({ code: -1, msg: '推流地址不能为空' });

    const ch = queryOne('SELECT * FROM channels WHERE id = ?', [parseInt(channel_id)]);
    if (!ch) return res.json({ code: -1, msg: '通道不存在' });

    const id = run(
      `INSERT INTO live_pushes (channel_id, platform, push_url, push_key, enable) VALUES (?, ?, ?, ?, ?)`,
      [parseInt(channel_id), platform || '自定义', push_url, push_key || '', enable !== undefined ? enable : 1]
    );

    logger.info('LivePush', `添加推流: [${ch.name}] -> [${platform}] ID:${id}`);

    // 自动启动
    if (enable !== 0) {
      const push = queryOne('SELECT * FROM live_pushes WHERE id = ?', [id]);
      if (push) pushManager.start(push);
    }

    res.json({ code: 0, data: { id } });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 更新推流任务
router.put('/pushes/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const old = queryOne('SELECT * FROM live_pushes WHERE id = ?', [id]);
    if (!old) return res.json({ code: -1, msg: '推流任务不存在' });

    const { channel_id, platform, push_url, push_key, enable } = req.body;

    run(
      `UPDATE live_pushes SET channel_id=?, platform=?, push_url=?, push_key=?, enable=?, updated_at=datetime('now','localtime') WHERE id=?`,
      [
        channel_id !== undefined ? parseInt(channel_id) : old.channel_id,
        platform || old.platform,
        push_url || old.push_url,
        push_key !== undefined ? push_key : old.push_key,
        enable !== undefined ? enable : old.enable,
        id,
      ]
    );

    // 重启推流
    pushManager.stop(id);
    const updated = queryOne('SELECT * FROM live_pushes WHERE id = ?', [id]);
    if (updated && updated.enable) {
      setTimeout(() => pushManager.start(updated), 500);
    }

    logger.info('LivePush', `更新推流 ID:${id}`);
    res.json({ code: 0, msg: '更新成功' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 删除推流任务
router.delete('/pushes/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    pushManager.stop(id);
    run('DELETE FROM live_pushes WHERE id = ?', [id]);
    logger.info('LivePush', `删除推流 ID:${id}`);
    res.json({ code: 0, msg: '删除成功' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 启动推流
router.post('/pushes/:id/start', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const push = queryOne('SELECT * FROM live_pushes WHERE id = ?', [id]);
    if (!push) return res.json({ code: -1, msg: '推流任务不存在' });

    // 确保通道流在运行
    const streamStatus = require('../lib/streamManager').getStatus(push.channel_id);
    if (streamStatus.status !== 'running') {
      const ch = queryOne('SELECT * FROM channels WHERE id = ?', [push.channel_id]);
      if (ch) require('../lib/streamManager').start(ch);
    }

    const result = pushManager.start(push);
    if (result.ok) {
      run("UPDATE live_pushes SET status='running' WHERE id=?", [id]);
    }
    res.json({ code: result.ok ? 0 : -1, data: result });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

// 停止推流
router.post('/pushes/:id/stop', (req, res) => {
  try {
    pushManager.stop(parseInt(req.params.id));
    run("UPDATE live_pushes SET status='stopped' WHERE id=?", [parseInt(req.params.id)]);
    res.json({ code: 0, msg: '已停止' });
  } catch (e) {
    res.json({ code: -1, msg: e.message });
  }
});

module.exports = router;

