'use strict';
// ============ 状态 ============
const state = {
  token: localStorage.getItem('token') || '',
  channels: [],
  hlsPlayers: {},
  playerTypes: {},
  currentPage: 'dashboard',
  refreshTimer: null,
};

const PLATFORMS = {
  'B站直播': 'rtmp://live-push.bilivideo.com/live-bvc/',
  '抖音直播': 'rtmp://push.douyin.com/live/',
  '斗鱼直播': 'rtmp://sendtc.douyu.com/live/',
  '虎牙直播': 'rtmp://va.openhuya.com/huya/',
  'YouTube': 'rtmp://a.rtmp.youtube.com/live2/',
  'Twitch': 'rtmp://live-jfk.twitch.tv/app/',
  '自定义RTMP': '',
};

// ============ Toast 通知 ============
function showToast(msg, type) {
  type = type || 'info';
  var container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  var toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(function() {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(function() { toast.remove(); }, 300);
  }, 3000);
}

// ============ 确认对话框 ============
function showConfirm(msg, onOk) {
  var html = '<div style="padding:8px 0;color:var(--text-secondary);font-size:14px">' + msg + '</div>' +
    '<div class="form-actions">' +
      '<button class="btn btn-default" onclick="closeGenericDialog()">取消</button>' +
      '<button class="btn btn-danger" id="confirm-ok-btn">确定</button>' +
    '</div>';
  showGenericDialog('确认', html);
  document.getElementById('confirm-ok-btn').onclick = function() {
    closeGenericDialog();
    onOk();
  };
}

// ============ API ============
async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api/v1' + path, opts);
  return res.json();
}

// ============ 登录 ============
async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  const res = await api('POST', '/login', { username, password });
  if (res.code === 0) {
    state.token = res.data.token;
    localStorage.setItem('token', state.token);
    document.getElementById('user-info').textContent = res.data.username;
    showMainApp();
  } else {
    showToast(res.msg || '登录失败', 'error');
  }
  return false;
}

function handleLogout() {
  state.token = '';
  localStorage.removeItem('token');
  location.reload();
}

function showMainApp() {
  document.getElementById('login-page').style.display = 'none';
  document.getElementById('main-app').style.display = 'flex';
  switchPage('dashboard');
  startAutoRefresh();
}

// ============ 页面切换 ============
function switchPage(page) {
  state.currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pageEl = document.getElementById('page-' + page);
  const navEl = document.querySelector('[data-page="' + page + '"]');
  if (pageEl) pageEl.classList.add('active');
  if (navEl) navEl.classList.add('active');

  if (page === 'dashboard') loadDashboard();
  else if (page === 'live') loadLiveView();
  else if (page === 'channels') loadChannels();
  else if (page === 'logs') loadLogs();
  else if (page === 'livepush') loadLivePush();
}

// ============ 控制台 ============
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
}

function getBarClass(percent) {
  if (percent >= 90) return ' danger';
  if (percent >= 70) return ' warning';
  return '';
}

async function loadDashboard() {
  const res = await api('GET', '/server-info');
  if (res.code !== 0) return;
  const d = res.data;

  // 统计卡片
  document.getElementById('stat-channels').textContent = d.channelCount;
  document.getElementById('stat-running').textContent = d.runningCount;
  document.getElementById('stat-errors').textContent = d.errorCount || 0;
  document.getElementById('stat-uptime').textContent = d.uptime;
  document.getElementById('node-version').textContent = d.nodeVersion;

  // 系统资源
  if (d.cpu) {
    const cpuBar = document.getElementById('cpu-bar');
    cpuBar.style.width = d.cpu.percent + '%';
    cpuBar.className = 'progress-fill' + getBarClass(d.cpu.percent);
    document.getElementById('cpu-text').textContent = d.cpu.percent + '%';
    document.getElementById('cpu-model').textContent = d.cpu.model.replace(/\(R\)|\(TM\)/g, '').trim().substring(0, 40);
  }
  if (d.memory) {
    const memBar = document.getElementById('mem-bar');
    memBar.style.width = d.memory.percent + '%';
    memBar.className = 'progress-fill' + getBarClass(d.memory.percent);
    document.getElementById('mem-text').textContent = d.memory.percent + '% (' + formatBytes(d.memory.used) + ' / ' + formatBytes(d.memory.total) + ')';
  }
  if (d.disk) {
    const diskBar = document.getElementById('disk-bar');
    diskBar.style.width = d.disk.percent + '%';
    diskBar.className = 'progress-fill' + getBarClass(d.disk.percent);
    document.getElementById('disk-text').textContent = d.disk.percent + '% (' + formatBytes(d.disk.used) + ' / ' + formatBytes(d.disk.total) + ')';
  }
  document.getElementById('ffmpeg-count').textContent = (d.ffmpegCount || 0) + ' 个进程';
  document.getElementById('storage-size').textContent = formatBytes(d.storageSize);

  // 通道状态列表
  const channels = await api('GET', '/channels');
  if (channels.code === 0) {
    const container = document.getElementById('channel-status-list');
    if (channels.data.length === 0) {
      container.innerHTML = '<div class="empty-state" style="padding:30px"><i class="mdi mdi-cctv empty-state-icon"></i>暂无通道</div>';
    } else {
      container.innerHTML = channels.data.map(function(ch) {
        const status = ch.stream_status || 'stopped';
        const statusText = { running: '运行中', connecting: '连接中', error: '异常', stopped: '已停止' }[status] || '未知';
        return '<div class="ch-status-item">' +
          '<div class="ch-status-dot ' + status + '"></div>' +
          '<div class="ch-status-name">' + (ch.name || '通道 ' + ch.id) + '</div>' +
          '<div class="ch-status-url">' + ch.stream_url + '</div>' +
          '<span class="badge badge-' + ({ running: 'success', connecting: 'warning', error: 'danger', stopped: 'default' }[status] || 'default') + ' ch-status-badge">' + statusText + '</span>' +
        '</div>';
      }).join('');
    }
  }

  // 最近日志
  if (d.recentLogs) {
    const levelBadge = function(l) {
      const m = { info: 'success', warn: 'warning', error: 'danger' };
      return '<span class="badge badge-' + (m[l] || 'default') + '">' + l.toUpperCase() + '</span>';
    };
    document.getElementById('dash-log-list').innerHTML = d.recentLogs.map(function(log) {
      return '<tr><td>' + log.created_at + '</td><td>' + levelBadge(log.level) + '</td><td>' + log.module + '</td><td>' + log.message + '</td></tr>';
    }).join('');
  }
}

async function startAllStreams() {
  const res = await api('POST', '/streams/start-all');
  if (res.code === 0) showToast('已启动 ' + res.data.started + '/' + res.data.total + ' 个通道', 'success');
  else showToast('启动失败', 'error');
}

async function stopAllStreams() {
  showConfirm('确定停止所有通道?', async function() {
    const channels = await api('GET', '/channels');
    if (channels.code === 0) {
      for (const ch of channels.data) {
        await api('POST', '/streams/' + ch.id + '/stop');
      }
      showToast('已停止所有通道', 'success');
      loadDashboard();
    }
  });
}

// ============ 实时预览 ============
async function loadLiveView() {
  const res = await api('GET', '/channels');
  if (res.code === 0) { state.channels = res.data; renderGrid(); }
}

function changeGrid() { renderGrid(parseInt(document.getElementById('grid-select').value)); }

function renderGrid(gridSize) {
  if (!gridSize) gridSize = 2;
  const container = document.getElementById('live-grid');
  container.className = 'live-grid grid-' + gridSize + 'x' + gridSize;
  Object.keys(state.hlsPlayers).forEach(id => destroyPlayer(parseInt(id)));
  state.hlsPlayers = {};
  state.playerTypes = {};

  const total = gridSize * gridSize;
  let html = '';
  for (let i = 0; i < total; i++) {
    const ch = state.channels[i];
    if (ch) {
      var statusText = { running: '运行中', connecting: '连接中', error: '异常', stopped: '已停止' }[ch.stream_status] || '未知';
      html += '<div class="video-cell" id="cell-' + ch.id + '">' +
        '<div class="cell-header">' + (ch.name || '通道 ' + ch.id) + '</div>' +
        '<span class="cell-status status-' + (ch.stream_status || 'stopped') + '">' + statusText + '</span>' +
        '<div class="cell-overlay" id="overlay-' + ch.id + '"><i class="mdi mdi-cctv"></i><span>等待连接...</span></div>' +
        '<video id="video-' + ch.id + '" muted autoplay></video>' +
        '<div class="cell-toolbar">' +
          '<button onclick="startStream(' + ch.id + ')"><i class="mdi mdi-play"></i> 播放</button>' +
          '<button onclick="stopStream(' + ch.id + ')"><i class="mdi mdi-stop"></i> 停止</button>' +
        '</div></div>';
    } else {
      html += '<div class="video-cell"><div class="cell-overlay"><i class="mdi mdi-plus-circle-outline"></i><span>空闲窗口</span></div></div>';
    }
  }
  container.innerHTML = html;
  state.channels.forEach((ch, i) => {
    if (i < total && ch.stream_status === 'running' && ch.hls_path) playStream(ch.id, ch.hls_path);
  });
}

function destroyPlayer(channelId) {
  const p = state.hlsPlayers[channelId];
  if (!p) return;
  if (state.playerTypes[channelId] === 'flv') {
    try { p.unload(); p.detachMediaElement(); p.destroy(); } catch (e) {}
  } else {
    try { p.destroy(); } catch (e) {}
  }
  delete state.hlsPlayers[channelId];
  delete state.playerTypes[channelId];
}

function setOverlayText(channelId, text) {
  var overlay = document.getElementById('overlay-' + channelId);
  if (overlay) {
    overlay.style.display = 'flex';
    var span = overlay.querySelector('span');
    if (span) span.textContent = text;
  }
}

function playStream(channelId, hlsPath) {
  var video = document.getElementById('video-' + channelId);
  var overlay = document.getElementById('overlay-' + channelId);
  if (!video) return;

  destroyPlayer(channelId);
  setOverlayText(channelId, '正在连接...');

  // 优先使用 mpegts.js (WebSocket-FLV, 低延迟)
  if (typeof mpegts !== 'undefined' && mpegts.isSupported()) {
    try {
      var wsProtocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      var wsUrl = wsProtocol + '//' + location.host + '/ws/live/' + channelId;
      setOverlayText(channelId, '正在建立 WebSocket 连接...');
      var player = mpegts.createPlayer({
        type: 'flv',
        isLive: true,
        url: wsUrl,
      }, {
        enableWorker: true,
        liveBufferLatencyChasing: true,
        liveBufferLatencyMaxLatency: 1.5,
        liveBufferLatencyMinRemain: 0.3,
      });
      player.attachMediaElement(video);
      player.load();
      player.play().catch(function() {});
      // WebSocket 连接超时: 5秒内未出画面则回退到 HLS
      var wsTimeout = setTimeout(function() {
        console.warn('WebSocket 连接超时, 回退到 HLS, channel:', channelId);
        destroyPlayer(channelId);
        playHlsFallback(channelId, hlsPath, video, overlay);
      }, 5000);
      player.on(mpegts.Events.ERROR, function() {
        clearTimeout(wsTimeout);
        destroyPlayer(channelId);
        playHlsFallback(channelId, hlsPath, video, overlay);
      });
      video.addEventListener('playing', function onPlaying() {
        clearTimeout(wsTimeout);
        if (overlay) overlay.style.display = 'none';
        video.removeEventListener('playing', onPlaying);
      });
      state.hlsPlayers[channelId] = player;
      state.playerTypes[channelId] = 'flv';
      return;
    } catch (e) {
      console.warn('mpegts 创建失败, 回退到 HLS:', e);
    }
  }

  // 回退: HLS 播放
  playHlsFallback(channelId, hlsPath, video, overlay);
}

function playHlsFallback(channelId, hlsPath, video, overlay) {
  setOverlayText(channelId, '正在通过 HLS 加载...');
  if (Hls.isSupported()) {
    var hls = new Hls({
      liveDurationInfinity: true,
      lowLatencyMode: true,
      maxBufferLength: 1,
      maxMaxBufferLength: 3,
      manifestLoadingRetryDelay: 500,
      levelLoadingRetryDelay: 500,
      fragLoadingRetryDelay: 500,
      liveSyncDurationCount: 1,
      liveMaxLatencyDurationCount: 3,
      liveBackBufferLength: 0,
      enableWorker: true,
    });
    hls.loadSource(hlsPath);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, function() { video.play().catch(function() {}); if (overlay) overlay.style.display = 'none'; });
    hls.on(Hls.Events.ERROR, function(event, data) {
      if (data.fatal) {
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          setOverlayText(channelId, '网络错误, 正在重试...');
          hls.startLoad();
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          setOverlayText(channelId, '媒体错误, 正在恢复...');
          hls.recoverMediaError();
        } else {
          setOverlayText(channelId, '播放失败: ' + data.details);
          hls.destroy();
        }
      }
    });
    state.hlsPlayers[channelId] = hls;
    state.playerTypes[channelId] = 'hls';
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = hlsPath;
    video.addEventListener('loadedmetadata', function() { video.play().catch(function() {}); if (overlay) overlay.style.display = 'none'; });
  }
}

async function startStream(channelId) {
  const res = await api('POST', '/streams/' + channelId + '/start');
  if (res.code === 0) {
    showToast('流启动中...', 'info');
    setTimeout(() => { if (res.data && res.data.hlsPath) playStream(channelId, res.data.hlsPath); }, 3000);
  } else { showToast(res.msg || '启动失败', 'error'); }
}

async function stopStream(channelId) {
  await api('POST', '/streams/' + channelId + '/stop');
  destroyPlayer(channelId);
  const v = document.getElementById('video-' + channelId);
  const o = document.getElementById('overlay-' + channelId);
  if (v) v.src = '';
  if (o) { o.style.display = 'flex'; o.querySelector('span').textContent = '已停止'; }
}

// ============ 通道管理 ============
async function loadChannels() {
  const res = await api('GET', '/channels');
  if (res.code !== 0) return;
  state.channels = res.data;
  document.getElementById('channel-list').innerHTML = res.data.map(ch =>
    '<tr><td>' + ch.id + '</td><td>' + (ch.name || '-') + '</td>' +
    '<td class="text-truncate" title="' + ch.stream_url + '">' + ch.stream_url + '</td>' +
    '<td>' + statusBadge(ch.stream_status) + '</td>' +
    '<td>' + (ch.enable ? '<span class="text-success">是</span>' : '<span style="color:var(--text-muted)">否</span>') + '</td>' +
    '<td>' +
      '<button class="btn btn-sm btn-primary" onclick="editChannel(' + ch.id + ')"><i class="mdi mdi-pencil"></i></button> ' +
      '<button class="btn btn-sm btn-danger" onclick="deleteChannel(' + ch.id + ')"><i class="mdi mdi-delete"></i></button> ' +
      '<button class="btn btn-sm btn-success" onclick="showShareDialog(' + ch.id + ',\'' + (ch.name || '通道 ' + ch.id) + '\')"><i class="mdi mdi-qrcode"></i></button>' +
    '</td></tr>'
  ).join('');
}

function statusBadge(s) {
  const m = { running: 'success', connecting: 'warning', error: 'danger', stopped: 'default' };
  const t = { running: '运行中', connecting: '连接中', error: '错误', stopped: '已停止' };
  return '<span class="badge badge-' + (m[s] || 'default') + '">' + (t[s] || '未知') + '</span>';
}

function showChannelDialog(ch) {
  document.getElementById('edit-channel-id').value = ch ? ch.id : '';
  document.getElementById('edit-name').value = ch ? ch.name : '';
  document.getElementById('edit-stream-url').value = ch ? ch.stream_url : '';
  document.getElementById('edit-description').value = ch ? (ch.description || '') : '';
  document.getElementById('dialog-title').textContent = ch ? '编辑通道' : '添加通道';
  document.getElementById('channel-dialog').style.display = 'flex';
}

function closeChannelDialog() { document.getElementById('channel-dialog').style.display = 'none'; }

function editChannel(id) { const ch = state.channels.find(c => c.id === id); if (ch) showChannelDialog(ch); }

async function saveChannel(e) {
  e.preventDefault();
  const id = document.getElementById('edit-channel-id').value;
  const body = {
    name: document.getElementById('edit-name').value,
    stream_url: document.getElementById('edit-stream-url').value,
    description: document.getElementById('edit-description').value,
    enable: 1,
  };
  const res = id ? await api('PUT', '/channels/' + id, body) : await api('POST', '/channels', body);
  if (res.code === 0) { closeChannelDialog(); loadChannels(); showToast('保存成功', 'success'); }
  else showToast(res.msg || '保存失败', 'error');
  return false;
}

async function deleteChannel(id) {
  showConfirm('确定删除该通道?', async function() {
    const res = await api('DELETE', '/channels/' + id);
    if (res.code === 0) { loadChannels(); showToast('删除成功', 'success'); }
    else showToast(res.msg || '删除失败', 'error');
  });
}

// ============ 直播推流 ============
async function loadLivePush() {
  const chRes = await api('GET', '/channels');
  const sel = document.getElementById('push-channel-id');
  if (sel && chRes.code === 0) {
    sel.innerHTML = chRes.data.map(c => '<option value="' + c.id + '">' + (c.name || '通道 ' + c.id) + '</option>').join('');
  }

  const res = await api('GET', '/live/pushes');
  if (res.code !== 0) return;
  const container = document.getElementById('push-list');
  if (!res.data.length) {
    container.innerHTML = '<div class="empty-state"><i class="mdi mdi-broadcast empty-state-icon"></i>暂无推流任务<br><br>点击右上角「添加推流」开始</div>';
    return;
  }
  container.innerHTML = res.data.map(function(p) {
    const dotClass = p.live_status || 'stopped';
    const uptime = p.live_status === 'running' ? fmtUptime(p.uptime) : (p.live_error || '已停止');
    return '<div class="push-card">' +
      '<div class="push-card-header"><h4><span class="push-live-dot ' + dotClass + '"></span>' + p.platform + '</h4>' + statusBadge(p.live_status) + '</div>' +
      '<div class="push-info"><i class="mdi mdi-cctv"></i> ' + (p.channel_name || '通道 ' + p.channel_id) + '</div>' +
      '<div class="push-info"><i class="mdi mdi-broadcast"></i> ' + p.push_url + (p.push_key ? '/' + p.push_key.substring(0, 8) + '...' : '') + '</div>' +
      '<div class="push-status-bar"><i class="mdi mdi-clock-outline"></i> ' + uptime + '</div>' +
      '<div class="push-actions">' +
        (p.live_status === 'running'
          ? '<button class="btn btn-sm btn-default" onclick="stopPush(' + p.id + ')"><i class="mdi mdi-stop"></i> 停止</button>'
          : '<button class="btn btn-sm btn-success" onclick="startPush(' + p.id + ')"><i class="mdi mdi-play"></i> 推流</button>') +
        '<button class="btn btn-sm btn-primary" onclick="editPush(' + p.id + ')"><i class="mdi mdi-pencil"></i></button>' +
        '<button class="btn btn-sm btn-danger" onclick="deletePush(' + p.id + ')"><i class="mdi mdi-delete"></i></button>' +
      '</div></div>';
  }).join('');
}

function fmtUptime(ms) {
  if (!ms) return '-';
  const s = Math.floor(ms / 1000), m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (h > 0) return '已推流 ' + h + '时' + (m % 60) + '分';
  if (m > 0) return '已推流 ' + m + '分' + (s % 60) + '秒';
  return '已推流 ' + s + '秒';
}

function showPushDialog(push) {
  document.getElementById('edit-push-id').value = push ? push.id : '';
  document.getElementById('push-platform').value = push ? push.platform : 'B站直播';
  document.getElementById('push-url').value = push ? push.push_url : PLATFORMS['B站直播'];
  document.getElementById('push-key').value = push ? (push.push_key || '') : '';
  const sel = document.getElementById('push-channel-id');
  if (sel && push) sel.value = push.channel_id;
  document.getElementById('push-dialog-title').textContent = push ? '编辑推流' : '添加推流';
  document.getElementById('push-dialog').style.display = 'flex';
}

function closePushDialog() { document.getElementById('push-dialog').style.display = 'none'; }

function onPlatformChange() {
  const p = document.getElementById('push-platform').value;
  document.getElementById('push-url').value = PLATFORMS[p] || '';
}

async function editPush(id) {
  const res = await api('GET', '/live/pushes');
  if (res.code === 0) { const p = res.data.find(x => x.id === id); if (p) showPushDialog(p); }
}

async function savePush(e) {
  e.preventDefault();
  const id = document.getElementById('edit-push-id').value;
  const body = {
    channel_id: parseInt(document.getElementById('push-channel-id').value),
    platform: document.getElementById('push-platform').value,
    push_url: document.getElementById('push-url').value,
    push_key: document.getElementById('push-key').value,
    enable: 1,
  };
  const res = id ? await api('PUT', '/live/pushes/' + id, body) : await api('POST', '/live/pushes', body);
  if (res.code === 0) { closePushDialog(); loadLivePush(); showToast('保存成功', 'success'); }
  else showToast(res.msg || '保存失败', 'error');
  return false;
}

async function startPush(id) {
  const res = await api('POST', '/live/pushes/' + id + '/start');
  if (res.code === 0) { showToast('推流启动中...', 'info'); setTimeout(loadLivePush, 2000); }
  else showToast(res.msg || '启动失败', 'error');
}

async function stopPush(id) { await api('POST', '/live/pushes/' + id + '/stop'); loadLivePush(); showToast('已停止', 'info'); }

async function deletePush(id) {
  showConfirm('确定删除该推流任务?', async function() {
    const res = await api('DELETE', '/live/pushes/' + id);
    if (res.code === 0) { loadLivePush(); showToast('删除成功', 'success'); }
    else showToast(res.msg || '删除失败', 'error');
  });
}

// ============ 日志 ============
async function loadLogs() {
  const res = await api('GET', '/logs?limit=200');
  if (res.code !== 0) return;
  const levelBadge = l => {
    const m = { info: 'success', warn: 'warning', error: 'danger' };
    return '<span class="badge badge-' + (m[l] || 'default') + '">' + l.toUpperCase() + '</span>';
  };
  document.getElementById('log-list').innerHTML = res.data.map(log =>
    '<tr><td>' + log.created_at + '</td><td>' + levelBadge(log.level) + '</td><td>' + log.module + '</td><td>' + log.message + '</td></tr>'
  ).join('');
}

// ============ 自动刷新 ============
// 不同页面使用不同刷新频率, 避免轮询抢占视频带宽
var REFRESH_INTERVALS = {
  live: 3000,      // 实时预览: 3秒 (避免和视频流争抢带宽)
  dashboard: 2000, // 控制台: 2秒 (每次2个API请求)
  channels: 1000,  // 通道管理: 1秒
  livepush: 2000,  // 直播推流: 2秒
  logs: 3000       // 日志: 3秒
};
state._refreshTick = 0;
state._apiBusy = false;

function startAutoRefresh() {
  stopAutoRefresh();
  // 统一用1秒tick, 按页面控制实际刷新频率
  state.refreshTimer = setInterval(refreshCurrentPage, 1000);
  state._refreshTick = 0;
  updateRefreshIndicator(true);
}

function stopAutoRefresh() {
  if (state.refreshTimer) { clearInterval(state.refreshTimer); state.refreshTimer = null; }
  updateRefreshIndicator(false);
}

function toggleAutoRefresh() {
  if (state.refreshTimer) { stopAutoRefresh(); showToast('已停止自动刷新', 'info'); }
  else { startAutoRefresh(); showToast('已开启自动刷新', 'info'); }
}

function refreshCurrentPage() {
  state._refreshTick++;
  // 防止API请求堆积: 上一个请求未完成时跳过
  if (state._apiBusy) return;
  var interval = REFRESH_INTERVALS[state.currentPage] || 2000;
  if (state._refreshTick % Math.round(interval / 1000) !== 0) return;

  state._apiBusy = true;
  var done = function() { state._apiBusy = false; };

  if (state.currentPage === 'dashboard') { loadDashboard().then(done).catch(done); }
  else if (state.currentPage === 'channels') { loadChannels().then(done).catch(done); }
  else if (state.currentPage === 'livepush') { loadLivePush().then(done).catch(done); }
  else if (state.currentPage === 'logs') { loadLogs().then(done).catch(done); }
  else if (state.currentPage === 'live') { refreshLiveStatus().then(done).catch(done); }
  else done();
}

function updateRefreshIndicator(on) {
  var el = document.getElementById('refresh-indicator');
  if (el) {
    el.style.background = on ? 'var(--success)' : 'var(--text-muted)';
    el.title = on ? '自动刷新: 开启 (点击切换)' : '自动刷新: 关闭 (点击切换)';
  }
}

function refreshLiveStatus() {
  return api('GET', '/channels').then(function(res) {
    if (res.code !== 0) return;
    var oldChannels = state.channels;
    state.channels = res.data;
    state.channels.forEach(function(ch) {
      var old = oldChannels.find(function(c) { return c.id === ch.id; });
      var cell = document.getElementById('cell-' + ch.id);
      if (!cell) return;
      // 更新状态标签
      var badge = cell.querySelector('.cell-status');
      if (badge) {
        var statusText = { running: '运行中', connecting: '连接中', error: '异常', stopped: '已停止' }[ch.stream_status] || '未知';
        badge.textContent = statusText;
        badge.className = 'cell-status status-' + (ch.stream_status || 'stopped');
      }
      // 如果流从非running变为running, 自动播放
      if (ch.stream_status === 'running' && ch.hls_path && (!old || old.stream_status !== 'running')) {
        playStream(ch.id, ch.hls_path);
      }
      // 如果流从running变为非running, 显示overlay
      if (ch.stream_status !== 'running' && old && old.stream_status === 'running') {
        destroyPlayer(ch.id);
        var overlay = document.getElementById('overlay-' + ch.id);
        if (overlay) {
          overlay.style.display = 'flex';
          overlay.querySelector('span').textContent = ch.stream_status === 'error' ? '连接异常' : '已停止';
        }
      }
    });
  });
}

// ============ 导航绑定 ============
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    const page = item.dataset.page;
    if (page) switchPage(page);
  });
});

// ============ 初始化 ============
if (state.token) showMainApp();

// ============ 分享/扫码观看 ============
function showShareDialog(channelId, channelName) {
  api('POST', '/share/create', { channel_id: channelId }).then(function(res) {
    if (res.code !== 0) { showToast(res.msg || '创建失败', 'error'); return; }
    var d = res.data;
    var html = '<div class="share-dialog-content">' +
      '<h3>' + (d.title || channelName) + '</h3>' +
      '<img class="share-qr" src="/api/v1/share/qrcode/' + d.token + '">' +
      '<p class="share-url">' + d.url + '</p>' +
      '<p class="share-tip">用微信扫描二维码观看实时画面</p>' +
      '<div class="share-actions">' +
        '<button class="btn btn-primary" onclick="copyText(\'' + d.url + '\')">复制链接</button> ' +
        '<button class="btn btn-default" onclick="closeGenericDialog()">关闭</button>' +
      '</div></div>';
    showGenericDialog('分享观看', html);
  });
}

function copyText(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(function() { showToast('已复制到剪贴板', 'success'); });
  } else {
    var ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta);
    ta.select(); document.execCommand('copy');
    document.body.removeChild(ta);
    showToast('已复制到剪贴板', 'success');
  }
}

// 通用对话框
function showGenericDialog(title, innerHtml) {
  var overlay = document.getElementById('generic-dialog');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'generic-dialog';
    overlay.className = 'dialog-overlay';
    overlay.style.display = 'none';
    overlay.innerHTML = '<div class="dialog"><div class="dialog-header"><h4 id="generic-dialog-title"></h4><a href="#" onclick="closeGenericDialog()"><i class="mdi mdi-close"></i></a></div><div id="generic-dialog-body" style="padding:24px"></div></div>';
    document.body.appendChild(overlay);
  }
  document.getElementById('generic-dialog-title').textContent = title;
  document.getElementById('generic-dialog-body').innerHTML = innerHtml;
  overlay.style.display = 'flex';
}

function closeGenericDialog() {
  var el = document.getElementById('generic-dialog');
  if (el) el.style.display = 'none';
}
